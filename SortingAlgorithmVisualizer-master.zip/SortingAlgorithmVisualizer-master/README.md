### Please open the repository as its own workspace.
### open the terminal and type
```bash
cd src
javac Main.java
java Main
```

## Group Members
* Harshit
    - 22051682
* Sakshi Pathak
    - 22051722
* Pratik Raj
    - 22053176
* Richa Singal
    - 22053181
* Rishabh Dev Singh
    - 22053183
