public class Rectangle {
    static int width;
    private int height;

    Rectangle(int height){
        this.height = height;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

}
